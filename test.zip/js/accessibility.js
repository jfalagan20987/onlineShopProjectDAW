//Objeto con valores por defecto
let settings = {
  fontSize: 1,
  lineHeight: 1.5,
  wordSpace: 0,
  letterSpace: 0,
  contrast: "normal"
};

//Límites para la fuente
const MIN_FONT = 0.9;
const MAX_FONT = 1.2;
const FONT_STEP = 0.1;

//Cargamos localStorage
if (localStorage.getItem("accessibility")) {
  settings = JSON.parse(localStorage.getItem("accessibility"));
  applySettings();
}

//Abrir menú accesibilidad
$("#accessibility-btn").on("click", () => {
  $("#accessibility-menu").show();
});

//Cerrar menú accesibilidad
$("img[alt=close-accessibility]").on("click", () => {
  $("#accessibility-menu").hide();
});

$("img[alt=close-accessibility]").on("keydown", (e) => {
  if(e.key === "Enter" || e.key === "Space"){
    $("#accessibility-menu").hide();
  }
});

//Aplicar modos de contraste
$("button[data-contrast]").on("click", function () {
  let mode = $(this).data("contrast");

  $("body").removeClass("contrast-gray contrast-dark contrast-light contrast-saturation");

  if (mode !== "normal") {
    $("body").addClass("contrast-" + mode);
  }

  settings.contrast = mode;

  save();
});

//Tamaño fuente
$("#fontSize-plus").on("click", function () {
  if (settings.fontSize < MAX_FONT) {
    settings.fontSize += FONT_STEP;

    settings.fontSize = parseFloat(settings.fontSize.toFixed(2));

    applySettings();
    save();

  }
});

$("#fontSize-minus").on("click", function () {
  if (settings.fontSize > MIN_FONT) {
    settings.fontSize -= FONT_STEP;

    settings.fontSize = parseFloat(settings.fontSize.toFixed(2));

    applySettings();
    save();
  }
});

//Resetear
$(".reset").on("click", function () {

  //Forzamos valores por defecto
  settings = {
    fontSize: 1,
    lineHeight: 1.5,
    wordSpace: 0,
    letterSpace: 0,
    contrast: "normal"
  };

  localStorage.removeItem("accessibility");

  $("body").removeClass("contrast-gray contrast-dark contrast-light contrast-saturation")
          .removeAttr("style");

  applySettings();

});


//Aplicar valores
function applySettings() {
  settings.fontSize = Math.min(MAX_FONT, Math.max(MIN_FONT, settings.fontSize));

  $("body").css({
    "font-size": settings.fontSize + "em",
    "line-height": settings.lineHeight,
    "word-spacing": settings.wordSpace + "em",
    "letter-spacing": settings.letterSpace + "em"
  });


  $("body").removeClass("contrast-gray contrast-dark contrast-light contrast-saturation");

  if (settings.contrast !== "normal") {
    $("body").addClass("contrast-" + settings.contrast);
  }
}

//Guardar en local storage
function save() {
  localStorage.setItem("accessibility", JSON.stringify(settings));
}